import React from "react";

const nSigFigs = 5;

export const isInViewport = (elem, yMarginPercent) => {
  const bounding = elem.getBoundingClientRect();
  const yMargin =
    window.innerWidth > 900
      ? (window.innerHeight / 100) * yMarginPercent
      : window.innerHeight / 100;
  return (
    bounding.top >= yMargin &&
    bounding.bottom <=
      -yMargin + (window.innerHeight || document.documentElement.clientHeight)
  );
};

export function isNullish(val) {
  return val === null || val === undefined || Number.isNaN(val);
}

export function numberToSigFigNDecimals(x) {
  const abs = Math.abs(x);
  if (abs < 1e-10) {
    return 2;
  }

  const res = nSigFigs - Math.floor(Math.log(abs) / Math.log(10)) - 1;
  return Math.max(res, 0);
}

export function readableBigNumber(x) {
  const f = Intl.NumberFormat("en", { notation: "compact" });
  return f.format(x);
}

export function numberToString(x, nDecimals) {
  if (isNullish(x) || isNaN(x)) {
    return "";
  }

  if (nDecimals === null) {
    nDecimals = numberToSigFigNDecimals(x);
  }

  let res = x.toLocaleString(undefined, {
    minimumFractionDigits: nDecimals,
    maximumFractionDigits: nDecimals,
  });

  let hasNonzeroDigit = false;
  for (const char of res) {
    if (/^[1-9]$/.test(char)) {
      hasNonzeroDigit = true;
      break;
    }
  }
  if (!hasNonzeroDigit) {
    res = res.replace("-", "");
  }
  return res;
}

export function displayAsPercentage(value) {
  return `${numberToString(value * 100, 2)}%`;
}

export const ColoredDiff = (prev, cur) => {
  if (isNullish(prev) || isNullish(cur) || prev === 0) {
    return "0";
  }

  const diff = cur - prev;
  const relDiff = diff / prev;
  const sign = diff >= 0 ? "+" : "-";

  const text = `${sign}${displayAsPercentage(Math.abs(relDiff))}`;

  if (diff < 0) {
    return <span style={{ color: "#FF6687" }}>{text}</span>;
  }
  if (diff > 0) {
    return <span style={{ color: "#0A9981" }}>{text}</span>;
  }
  return <span>{text}</span>;
};
