import * as React from "react";

import Layout from "../components/Layout";
import Seo from "../components/SEO";
import TopBlock from "../components/TopBlock";
import CenteredContent from "../components/CenteredContent";
import Separator from "../components/Separator";
import TvBlock from "../components/TvBlock";
import { styled } from "styled-components";
import { StyledItalic, StyledMobileBreak } from "../components/Helpers";
import Decentralized from "../components/Decentralized";
import Currencies from "../components/Currencies";
import Roadmap from "../components/Roadmap";
import CtaBlock from "../components/CtaBlock";
import Stats from "../components/Stats";
import VeryBigTitle from "../components/VeryBigTitle";
import {
  StyledDarkGreenBlock,
  StyledGreenBlock,
  StyledLightGreenBlock,
} from "../components/Backgrounds";

const StyledBlob = styled.div`
  margin: 20px auto -20px;
  max-width: 137px;
`;

const StyledAnimatedBlob = styled.img`
  height: 137px;
  width: 137px;
`;

const StyleTitle = styled.div`
  font-family: "Teodor";
  font-style: normal;
  font-weight: 300;
  font-size: 64px;
  line-height: 64px;
  letter-spacing: -0.03em;
  color: #193833;
  text-align: center;

  @media screen and (max-width: 1024px) {
    font-size: 48px;
    line-height: 48px;
    letter-spacing: -0.03em;
  }
`;

const StyledSubtitle = styled.div`
  margin: 32px auto 71px;
  white-space: nowrap;
  font-family: "Inter";
  font-style: normal;
  font-weight: 400;
  font-size: 20px;
  line-height: 26px;
  color: rgba(25, 56, 51, 0.8);
  text-align: center;

  @media screen and (max-width: 1024px) {
    font-size: 14px;
  }
`;

const IndexPage = () => {
  const [currencies, setCurrencies] = React.useState([]);
  const [content, setContent] = React.useState([]);

  React.useEffect(() => {
    const loadCurrencies = async () => {
      const request = await fetch(
        `${process.env.GATSBY_ROOT_URL.split("app.").join("api.")}/info`,
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ type: "metaAndAssetCtxs" }),
        }
      );
      const content = await request.json();
      setContent(content);
      setCurrencies(content[0].universe.map(t => t.name));
    };

    loadCurrencies();
  }, []);

  return (
    <Layout>
      <TopBlock>
        <CenteredContent>
          <Separator size={90} />
          <StyledBlob>
            <StyledAnimatedBlob src="/gif/blob-dark.gif" alt="" />
          </StyledBlob>
          <StyleTitle>
            Trade&nbsp;perpetuals&nbsp;
            <StyledMobileBreak />
            <StyledItalic>seamlessly</StyledItalic>
          </StyleTitle>
          <StyledSubtitle>
            Hyperliquid is a decentralized perpetual exchange
            <br />
            with best-in-class speed, liquidity, and price.
          </StyledSubtitle>
          <Stats currencies={currencies} />
          <TvBlock />
        </CenteredContent>
      </TopBlock>
      <StyledGreenBlock>
        <CenteredContent>
          <Decentralized />
        </CenteredContent>
      </StyledGreenBlock>
      <StyledDarkGreenBlock>
        <CenteredContent>
          <Currencies currencies={currencies} content={content} />
        </CenteredContent>
      </StyledDarkGreenBlock>
      <StyledLightGreenBlock>
        <CenteredContent>
          <Roadmap />
        </CenteredContent>
      </StyledLightGreenBlock>
      <CtaBlock />
      <StyledLightGreenBlock>
        <CenteredContent>
          <VeryBigTitle />
        </CenteredContent>
      </StyledLightGreenBlock>
    </Layout>
  );
};

export const Head = () => <Seo title="Home" />;

export default IndexPage;
