import classNames from "classnames";
import React from "react";
import { StyledGrid } from "./Grid.styled";

const Grid = React.forwardRef(
  (
    {
      className,
      children,
      style,
      display = "grid",
      asHTMLTag,
      gridAutoRows,
      gridTemplateColumns,
      gridTemplateRows,
      gridColumnStart,
      gridColumnEnd,
      gridTemplateAreas,
      gridTemplate,
      gap,
      columnGap,
      rowGap,
      justifyItems,
      alignItems,
      justifyContent,
      alignContent,
      ...interactionEvents
    },
    ref
  ) => {
    return (
      <StyledGrid
        ref={ref}
        as={asHTMLTag}
        {...interactionEvents}
        className={classNames(className)}
        style={{
          ...style,
          ...(display ? { display } : {}),
          ...(gridAutoRows ? { gridAutoRows } : {}),
          ...(gridTemplateColumns ? { gridTemplateColumns } : {}),
          ...(gridTemplateRows ? { gridTemplateRows } : {}),
          ...(gridColumnStart ? { gridColumnStart } : {}),
          ...(gridColumnEnd ? { gridColumnEnd } : {}),
          ...(gridTemplateAreas ? { gridTemplateAreas } : {}),
          ...(gridTemplate ? { gridTemplate } : {}),
          ...(gap ? { gap } : {}),
          ...(columnGap ? { columnGap } : {}),
          ...(rowGap ? { rowGap } : {}),
          ...(justifyItems ? { justifyItems } : {}),
          ...(alignItems ? { alignItems } : {}),
          ...(justifyContent ? { justifyContent } : {}),
          ...(alignContent ? { alignContent } : {}),
        }}
      >
        {children}
      </StyledGrid>
    );
  }
);

export default Grid;
