import styled from "styled-components";

export const StyledGrid = styled.div``;
