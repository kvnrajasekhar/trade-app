import React from "react";
import { styled } from "styled-components";

const StyledCenteredContent = styled.div`
  margin: 0 auto;
  width: ${({ width }) => `${width}px`};
  max-width: calc(100% - 60px);
`;

export default function CenteredContent({ children, width = 1200 }) {
  return (
    <StyledCenteredContent width={width}>{children}</StyledCenteredContent>
  );
}
