import React from "react";
import Separator from "../Separator";
import { styled } from "styled-components";
import { ColoredDiff, readableBigNumber } from "../../utils";

const usesWhiteBackground = ["ETH"];
const nameMapping = {
  ADA: "Cardano",
  APT: "Aptos",
  ATOM: "Cosmos",
  AVAX: "Avalanche",
  BCH: "Bitcoin Cash",
  BNB: "Binance",
  BTC: "Bitcoin",
  CHZ: "Chiliz",
  DOGE: "Dogecoin",
  EOS: "EOS",
  ETC: "Ethereum Classic",
  ETH: "Ethereum",
  LINK: "Chainlink",
  INJ: "Injective",
  LIT: "Litentry",
  LTC: "Litecoin",
  LDO: "Lido",
  MASK: "Mask",
  MATIC: "Polygon",
  PEOPLE: "ConstitutionDAO",
  SOL: "Solana",
  XRP: "Ripple",
  APE: "ApeCoin",
  OP: "Optimism",
  DYDX: "dYdX",
  ARB: "Arbitrum",
  kPEPE: "kPepe",
  STX: "Stacks",
  CRV: "Curve",
  FTM: "Fantom",
  RNDR: "Render",
  SNX: "Synthetix",
  CFX: "Conflux",
  GMX: "GMX",
  AAVE: "Aave",
  COMP: "Compound",
  MKR: "Maker",
  WLD: "Worldcoin",
  HPOS: "HPOS10I",
  FXS: "Frax",
  UNIBOT: "UniBot",
  RLB: "Rollbit",
  RUNE: "THORChain",
  SHIB: "Shiba",
  kSHIB: "Shiba",
  SEI: "Sei Network",
  TRX: "Tron",
  UNI: "Uniswap",
  YGG: "Yield Guild Games",
  OX: "OPNX",
  FRIEND: "Friend Index",
  SUI: "Sui",
  SHIA: "Shiba Saga",
  CYBER: "CyberConnect",
  ZRO: "Layer Zero",
  BLZ: "Bluzelle",
  DOT: "Polkadot",
  TRB: "Tellor",
  FTT: "FTX Token",
  OGN: "Origin Protocol",
  LOOM: "Loom Network",
  BNT: "Bancor",
  CANTO: "Canto",
  RDNT: "Radiant Capital",
  ARK: "Ark",
  BIGTIME: "Big Time",
  KAS: "Kaspa",
  REQ: "Request",
  BLUR: "Blur",
  ORBS: "Orbs",
  BSV: "Bitcoin SV",
  TIA: "Celestia",
  TON: "Toncoin",
  MINA: "Mina Protocol",
  POLYX: "Polymesh",
  STG: "Stargate",
  STRAX: "Stratix",
  PENDLE: "Pendle",
  FET: "Fetch.ai",
  GAS: "Gas",
  NEAR: "Near Protocol",
  MEME: "Meme Coin",
  ORDI: "Ordinals",
  NEO: "Neo",
  ZEN: "Horizen",
  BADGER: "Badger",
  FIL: "Filecoin",
  PYTH: "Pyth",
  BONK: "Bonk",
  SUSHI: "SushiSwap",
  ILV: "Illuvium",
  IMX: "Immutable",
  BANANA: "Banana Gun",
  NFTI: "NFT Index",
  SUPER: "SuperVerse DAO",
  GMT: "STEPN",
  USTC: "TerraClassicUSD",
  JUP: "Jupiter Exchange",
  kLUNC: "Terra Luna Classic",
  GALA: "Gala Games",
  RSR: "Reserve Rights",
  JTO: "Jito",
  NTRN: "Neutron",
  ACE: "Fusionist",
  MAV: "Maverick",
  ENS: "ENS",
  CAKE: "PancakeSwap",
  XAI: "Xai Network",
  UMA: "UMA",
  MANTA: "Manta Network",
  ONDO: "Ondo Finance",
  ALT: "AltLayer",
  ZETA: "ZetaChain",
  MAVIA: "Heroes of Mavia",
  DYM: "Dymension",
  W: "Wormhole",
  PANDORA: "PANDORA",
  STRK: "Starknet",
  AI: "Sleepless AI",
  PIXEL: "Pixels",
  TAO: "Bittensor",
  AR: "Arweave",
  kFLOKI: "kFloki",
  BOME: "Book of Meme",
};

const StyledList = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;

  @media screen and (max-width: 1024px) {
    grid-template-columns: 1fr;
    gap: 12px;
  }

  & .currency-block {
    position: relative;
    padding: 12px;
    background: #0f2e29;
    border-radius: 8px;
  }

  & .currency-block-effect-1 {
    text-decoration: none;
    display: block;
    cursor: pointer;
    margin: 0;
    border-radius: 8px;
    transition: margin 0.3s ease-out;
  }

  & .currency-block-effect-1:active {
    text-decoration: none;
  }

  & .currency-block-effect-1:hover {
    background: linear-gradient(
      -170deg,
      rgba(125, 255, 208, 0.05),
      rgba(125, 255, 208, 0.16),
      rgba(125, 255, 208, 0.5)
    );
    margin: -7px;
  }

  & .currency-block-effect-2 {
    border-radius: 8px;
    margin: 0px;
    background: #02231e;
    transition: margin 0.3s ease-out, padding 0.3s ease-out;
  }

  & .currency-block-effect-1:hover .currency-block-effect-2 {
    margin: 1px;
    padding: 6px;
  }

  & .currency-block-effect-3 {
    border-radius: 9px;
    background: linear-gradient(
      -170deg,
      rgba(125, 255, 208, 0.2),
      rgba(125, 255, 208, 0.46),
      rgba(125, 255, 208, 1)
    );
  }

  & .currency-block-effect-4 {
    border-radius: 8px;
    padding: 1px;
    background: #0f2e29;
    transition: background 0.3s ease-out;
  }

  & .currency-block-effect-1:hover .currency-block-effect-4 {
    background: rgba(0, 0, 0, 0);
  }

  & .currency-block .top-line {
    display: flex;
    gap: 12px;
    align-items: center;
    margin-bottom: 28px;
  }

  & .currency-block .top-line img {
    display: block;
    width: 56px;
    height: 56px;
    border-radius: 100px;
  }

  & .currency-block .top-line img.with-white-bg {
    background: #ffffff;
  }

  & .currency-block .top-line .token {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  & .currency-block .top-line .token h2 {
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 20px;
    line-height: 26px;
    color: #dbfbf6;
    white-space: nowrap;
  }

  & .currency-block .top-line .token h3 {
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 16px;
    line-height: 21px;
    color: #ffffff;
    opacity: 0.5;
  }

  & .currency-block .bottom-line {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    align-items: center;
  }

  & .bottom-line > div {
    font-family: "Inter";
    font-style: normal;
    font-weight: 300;
    font-size: 24px;
    line-height: 31px;
    color: #ffffff;
  }

  & .bottom-line .values div {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
  }

  & .bottom-line .values .label {
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    color: #ffffff;
    opacity: 0.25;
    text-transform: uppercase;
  }

  & .bottom-line .values .chg-negative {
    color: #ea580c;
  }

  & .bottom-line .values .chg-positive {
    color: #97fce4;
  }

  & .bottom-line .values .volume {
    color: #ffffff;
  }

  @media screen and (max-width: 1024px) {
    & .currency-block {
      display: grid;
      grid-template-columns: 1fr auto;
      align-items: start;
    }

    & .currency-block .top-line {
      margin-bottom: 0;
    }

    & .currency-block .bottom-line .values {
      display: none;
    }

    & .currency-block .top-line img {
      width: 40px;
      height: 40px;
    }
  }
`;

const Currencies = ({ currencies, content }) => {
  return (
    <>
      <Separator size={96} />
      <iframe
        width="100%"
        style={{ aspectRatio: "16/9" }}
        src="https://www.youtube-nocookie.com/embed/XkUO190lBrQ"
        title="YouTube video player"
        frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen
      ></iframe>
      <Separator size={190} />
      <StyledList>
        {currencies.map((token, i) => (
          <a
            href={`${process.env.GATSBY_ROOT_URL}/trade/${token}`}
            key={i}
            className="currency-block-effect-1"
          >
            <div className="currency-block-effect-2">
              <div className="currency-block-effect-3">
                <div className="currency-block-effect-4">
                  <div className="currency-block">
                    <div className="top-line">
                      <img
                        src={`/svg/currencies/${token}.svg`}
                        alt=""
                        onError={e => {
                          e.target.src = "/svg/currencies/missing.svg";
                          e.target.classList.add("with-white-bg");
                        }}
                        className={`${
                          usesWhiteBackground.includes(token)
                            ? "with-white-bg"
                            : ""
                        }`}
                      />
                      <div className="token">
                        <h2>{nameMapping[token] || token}</h2>
                        <h3>{token}</h3>
                      </div>
                    </div>
                    <div className="bottom-line">
                      <div>
                        $
                        {new Intl.NumberFormat().format(content[1][i].oraclePx)}
                      </div>
                      <div className="values">
                        <div>
                          <div className="label">Chg</div>
                          <div className="chg-negative">
                            {ColoredDiff(
                              content[1][i].prevDayPx,
                              content[1][i].oraclePx
                            )}
                          </div>
                        </div>
                        <div>
                          <div className="label">Vol</div>
                          <div className="volume">
                            ${readableBigNumber(content[1][i].dayNtlVlm)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </a>
        ))}
      </StyledList>
      <Separator size={96} />
    </>
  );
};

export default Currencies;
