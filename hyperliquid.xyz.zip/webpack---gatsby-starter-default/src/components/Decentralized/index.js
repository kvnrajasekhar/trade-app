import React, { useEffect, useRef } from "react";
import { styled } from "styled-components";
import { isInViewport } from "../../utils";
import PropertyBlock from "../PropertyBlock";

const StyledDecentralized = styled.div`
  display: flex;
  flex-direction: column;
  padding: 48px 0;
  margin: 0 auto;
  position: relative;

  & span {
    position: relative;
    font-size: 28px;
    text-transform: uppercase;
    color: #97fce4;
    letter-spacing: 11px;
    display: inline-block;
  }

  & span::after {
    position: absolute;
    content: attr(data-content);
    top: 0;
    left: 0;
  }

  @media screen and (max-width: 1024px) {
    font-size: 20px;
    line-height: 28px;
    padding: 48px auto;

    & span {
      position: relative;
      font-size: 20px;
      letter-spacing: 6px;
    }
  }
`;

const StyledFixer = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 78px;
  background: #072723;
  z-index: 900;

  @media screen and (max-width: 1024px) {
    display: none;
  }
`;

const StyledTitle = styled.div`
  font-family: "Inter";
  font-style: normal;
  font-weight: 300;
  font-size: 28px;
  line-height: 28px;
  color: #ffffff;
  margin: 118px auto;
  text-align: center;

  & span,
  & span::after {
    transition: transform 0.5s ease-out;
  }

  &.animated span:nth-child(2) {
    transform: translateY(-20px);
  }
  &.animated span:nth-child(2)::after {
    transform: translateY(40px);
  }

  &.animated span:nth-child(3) {
    transform: translateY(-50px);
  }
  &.animated span:nth-child(3)::after {
    transform: translateY(100px);
  }

  &.animated span:nth-child(4) {
    transform: translateY(-37px);
  }
  &.animated span:nth-child(4)::after {
    transform: translateY(74px);
  }

  &.animated span:nth-child(5) {
    transform: translateY(-16px);
  }
  &.animated span:nth-child(5)::after {
    transform: translateY(32px);
  }

  &.animated span:nth-child(7) {
    transform: translateY(-16px);
  }
  &.animated span:nth-child(7)::after {
    transform: translateY(32px);
  }

  &.animated span:nth-child(8) {
    transform: translateY(-37px);
  }
  &.animated span:nth-child(8)::after {
    transform: translateY(74px);
  }

  &.animated span:nth-child(9) {
    transform: translateY(-64px);
  }
  &.animated span:nth-child(9)::after {
    transform: translateY(128px);
  }

  &.animated span:nth-child(10) {
    transform: translateY(-80px);
  }
  &.animated span:nth-child(10)::after {
    transform: translateY(160px);
  }

  &.animated span:nth-child(11) {
    transform: translateY(-60px);
  }
  &.animated span:nth-child(11)::after {
    transform: translateY(120px);
  }

  &.animated span:nth-child(12) {
    transform: translateY(-30px);
  }
  &.animated span:nth-child(12)::after {
    transform: translateY(60px);
  }

  &.animated span:nth-child(13) {
    transform: translateY(0px);
  }
  &.animated span:nth-child(13)::after {
    transform: translateY(0px);
  }

  @media screen and (max-width: 1024px) {
    &.animated span:nth-child(2) {
      transform: translateY(-15px);
    }
    &.animated span:nth-child(2)::after {
      transform: translateY(30px);
    }

    &.animated span:nth-child(3) {
      transform: translateY(-37px);
    }
    &.animated span:nth-child(3)::after {
      transform: translateY(75px);
    }

    &.animated span:nth-child(4) {
      transform: translateY(-29px);
    }
    &.animated span:nth-child(4)::after {
      transform: translateY(65px);
    }

    &.animated span:nth-child(5) {
      transform: translateY(-12px);
    }
    &.animated span:nth-child(5)::after {
      transform: translateY(24px);
    }

    &.animated span:nth-child(7) {
      transform: translateY(-12px);
    }
    &.animated span:nth-child(7)::after {
      transform: translateY(24px);
    }

    &.animated span:nth-child(8) {
      transform: translateY(-29px);
    }
    &.animated span:nth-child(8)::after {
      transform: translateY(65px);
    }

    &.animated span:nth-child(9) {
      transform: translateY(-48px);
    }
    &.animated span:nth-child(9)::after {
      transform: translateY(96px);
    }

    &.animated span:nth-child(10) {
      transform: translateY(-62px);
    }
    &.animated span:nth-child(10)::after {
      transform: translateY(125px);
    }

    &.animated span:nth-child(11) {
      transform: translateY(-40px);
    }
    &.animated span:nth-child(11)::after {
      transform: translateY(80px);
    }

    &.animated span:nth-child(12) {
      transform: translateY(-20px);
    }
    &.animated span:nth-child(12)::after {
      transform: translateY(40px);
    }

    &.animated span:nth-child(13) {
      transform: translateY(0px);
    }
    &.animated span:nth-child(13)::after {
      transform: translateY(0px);
    }
  }
`;

const StyledContainer = styled.div`
  padding: 0 4px 0 16px;
  display: inline-block;

  @media screen and (max-width: 1024px) {
    display: block;
    padding: 120px 0 50px;
  }
`;

const Decentralized = () => {
  const ref = useRef();

  useEffect(() => {
    const scrollListener = () => {
      if (ref.current) {
        const inViewport = isInViewport(ref.current, 25);
        if (inViewport && !ref.current.classList.contains("animated")) {
          ref.current.classList.add("animated");
        }
        if (!inViewport && ref.current.classList.contains("animated")) {
          ref.current.classList.remove("animated");
        }
      }
    };

    window.addEventListener("scroll", scrollListener, false);

    return () => {
      window.removeEventListener("scroll", scrollListener);
    };
  }, [ref]);

  return (
    <StyledDecentralized>
      <StyledFixer />
      <StyledTitle ref={ref}>
        The CEX features you love, but
        <StyledContainer>
          <span data-content="d">d</span>
          <span data-content="e">e</span>
          <span data-content="c">c</span>
          <span data-content="e">e</span>
          <span data-content="n">n</span>
          <span data-content="t">t</span>
          <span data-content="r">r</span>
          <span data-content="a">a</span>
          <span data-content="l">l</span>
          <span data-content="i">i</span>
          <span data-content="z">z</span>
          <span data-content="e">e</span>
          <span data-content="d">d</span>
        </StyledContainer>
      </StyledTitle>
      <PropertyBlock />
    </StyledDecentralized>
  );
};

export default Decentralized;
