import * as React from "react";
import { useMixpanel } from "gatsby-plugin-mixpanel";
import Navbar from "../Navbar";
import CenteredContent from "../CenteredContent";
import Footer from "../Footer";
import FooterSecond from "../Footer/FooterSecond";
import { StyledDarkGreenBlock } from "../Backgrounds";
import "../main.css";

const Layout = ({ children }) => {
  const mixpanel = useMixpanel();

  React.useEffect(() => {
    if (process.env.GATSBY_ROOT_URL === "https://app.hyperliquid.xyz") {
      mixpanel.track("Landing page");
      function trackExit() {
        if (document.visibilityState === "hidden") {
          mixpanel.track("Exit Landing page", undefined, {
            transport: "sendBeacon",
          });
        }
      }
      document.addEventListener("visibilitychange", trackExit);
      return () => {
        document.removeEventListener("visibilitychange", trackExit);
      };
    }
  }, [mixpanel]);

  return (
    <div>
      <Navbar />
      {children}
      <StyledDarkGreenBlock>
        <CenteredContent>
          <Footer />
          <FooterSecond />
        </CenteredContent>
      </StyledDarkGreenBlock>
    </div>
  );
};

export default Layout;
