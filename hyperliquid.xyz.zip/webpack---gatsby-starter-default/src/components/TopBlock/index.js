import React from "react";
import { styled } from "styled-components";

const StyledTopBlock = styled.div`
  background: url(/svg/background-circles.svg);
  background-position: center 160px;
  background-repeat: no-repeat;
  background-size: auto;
  height: 1142px;

  @media screen and (max-width: 1024px) {
    height: auto !important;
    background-position: center 20px;
  }
`;

const TopBlock = ({ children }) => {
  return <StyledTopBlock>{children}</StyledTopBlock>;
};

export default TopBlock;
