import React from "react";
import { styled } from "styled-components";
import StyledBigButton from "./BigButton";

const StyledTvBlockRegular = styled.div`
  position: relative;
  max-width: 996px;
  height: 496px;
  margin: 0 auto;
  background: #02231e;
  border-radius: 12px 12px 0px 0px;
  padding: 13px 28px 0px 28px;
  box-sizing: border-box;
  box-shadow: 0px 0px 30px 5px rgba(151, 252, 215, 0.56);
`;

const StyledAction = styled.div`
  position: absolute;
  top: -28px;
  width: calc(100% - 56px);
  display: flex;
  justify-content: center;
`;

const StyledScreenshot = styled.div`
  width: 100%;
  height: 450px;
  background: url(/img/screenshot.png) no-repeat;
  background-size: cover;
`;

export default function TvBlockRegular() {
  return (
    <StyledTvBlockRegular>
      <StyledAction>
        <StyledBigButton href={`${process.env.GATSBY_ROOT_URL}/trade`}>
          Start Trading
        </StyledBigButton>
      </StyledAction>
      <StyledScreenshot />
    </StyledTvBlockRegular>
  );
}
