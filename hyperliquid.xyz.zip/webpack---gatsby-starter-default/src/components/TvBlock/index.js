import React from "react";
import { Media } from "../../Media";
import TvBlockMobile from "./TvBlockMobile";
import TvBlockRegular from "./TvBlockRegular";

export default function TvBlock() {
  return (
    <>
      <Media lessThan="lg">
        <TvBlockMobile />
      </Media>
      <Media greaterThan="md">
        <TvBlockRegular />
      </Media>
    </>
  );
}
