import React from "react";
import StyledBigButton from "./BigButton";
import { styled } from "styled-components";

const StyledTvBlockMobile = styled.div`
  position: relative;
  width: calc(100% - 70px);
  aspect-ratio: 280 / 350;
  background: url(/img/screenshot-mobile-2.png);
  background-repeat: no-repeat;
  background-size: cover;
  margin: 0 auto;
`;

const StyledAction = styled.div`
  position: absolute;
  top: -28px;
  width: calc(100% - 56px);
  display: flex;
  justify-content: center;
  width: 100%;
`;

export default function TvBlockMobile() {
  return (
    <StyledTvBlockMobile>
      <StyledAction>
        <StyledBigButton href={`${process.env.GATSBY_ROOT_URL}/trade`}>
          Start Trading
        </StyledBigButton>
      </StyledAction>
    </StyledTvBlockMobile>
  );
}
