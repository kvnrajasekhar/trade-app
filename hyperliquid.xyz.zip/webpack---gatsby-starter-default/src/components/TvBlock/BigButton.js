import { styled } from "styled-components";

const StyledBigButton = styled.a`
  padding: 9px 40px;
  box-sizing: border-box;
  height: 56px;
  background: #97fce4;
  border-radius: 60px;
  font-size: 20px;
  font-weight: 400;
  line-height: 38px;
  color: #193833;
  text-decoration: none;

  &:hover {
    background: #50d2c1;
    color: #193833;
  }

  &:active {
    background: #33998c;
    color: #193833;
  }
`;

export default StyledBigButton;
