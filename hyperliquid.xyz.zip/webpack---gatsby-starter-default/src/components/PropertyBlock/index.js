import React from "react";
import { Media } from "../../Media";
import PropertyBlockMobile from "./PropertyBlockMobile";
import PropertyBlockRegular from "./PropertyBlockRegular";

const PropertyBlock = () => {
  return (
    <>
      <Media lessThan="lg">
        <PropertyBlockMobile />
      </Media>
      <Media greaterThan="md">
        <PropertyBlockRegular />
      </Media>
    </>
  );
};

export default PropertyBlock;
