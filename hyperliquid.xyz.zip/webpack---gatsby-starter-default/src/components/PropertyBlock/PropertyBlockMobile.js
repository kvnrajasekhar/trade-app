import React from "react";
import Flex from "../Flex";
import { styled } from "styled-components";

const StyledContainer = styled.div`
  display: flex;
  gap: 8px;
  align-items: center;
  padding-bottom: 12px;
  border-bottom: 1px solid #23524c;

  &:last-child {
    border-bottom: none;
  }

  & img {
    height: 72px;
    width: 72px;
  }

  & div {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  & div .property-title {
    font-family: "Teodor";
    font-style: normal;
    font-weight: 300;
    font-size: 24px;
    line-height: 100%;
    letter-spacing: -0.02em;
    color: #dbfbf6;
  }

  & div .property-text {
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 130%;
    color: rgba(255, 255, 255, 0.8);
  }
`;

const PropertyBlockMobile = () => {
  return (
    <Flex flexDirection="column" gap={12}>
      <StyledContainer>
        <img src="/svg/powerful.svg" alt="" />
        <div>
          <div className="property-title">Powerful.</div>
          <div className="property-text">
            Advanced order types such as TWAP, Scale, and TP/SL. Modify and cancel directly from
            TradingView chart.
          </div>
        </div>
      </StyledContainer>

      <StyledContainer>
        <img src="/svg/fast.svg" alt="" />
        <div>
          <div className="property-title">Fast.</div>
          <div className="property-text">
            Instant finality in &lt;1 second.
            <br />
            No more waiting for confirmations. No more MEV.
          </div>
        </div>
      </StyledContainer>

      <StyledContainer>
        <img src="/svg/zero.svg" alt="" />
        <div>
          <div className="property-title">Low fees.</div>
          <div className="property-text">
            Zero gas, maker rebates, and low taker fees.
          </div>
        </div>
      </StyledContainer>

      <StyledContainer>
        <img src="/svg/leverage.svg" alt="" />
        <div>
          <div className="property-title">Up to 50x leverage.</div>
          <div className="property-text">
            Trade with conviction to maximize capital efficiency when it matters
            most.
          </div>
        </div>
      </StyledContainer>

      <StyledContainer>
        <img src="/svg/transparent.svg" alt="" />
        <div>
          <div className="property-title">Transparent.</div>
          <div className="property-text">
            Fully on-chain order book. Trades, funding, and liquidations all
            happen on the Hyperliquid L1.
          </div>
        </div>
      </StyledContainer>

      <StyledContainer>
        <img src="/svg/seamless.svg" alt="" />
        <div>
          <div className="property-title">Seamless.</div>
          <div className="property-text">
            One-click trading. No wallet approvals to interrupt your flow.
          </div>
        </div>
      </StyledContainer>
    </Flex>
  );
};

export default PropertyBlockMobile;
