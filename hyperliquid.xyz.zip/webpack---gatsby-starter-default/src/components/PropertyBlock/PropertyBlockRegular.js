import React from "react";
import { styled } from "styled-components";

const StyledContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  width: 1200px;
  max-width: 100%;
  margin: 0 auto;

  &.first {
    border-bottom: 1px solid #23524c;
  }
`;

const StyledLeft = styled.div`
  display: grid;
  grid-template-columns: auto 1fr;
  border-right: 1px solid #23524c;

  & img {
    width: 144px;
    height: 144px;
    transition: all 0.2s ease-in-out;
  }

  &:hover img {
    transform: scale(1.2);
  }

  & > div {
    margin: 40px 0;
  }

  & .property-title {
    font-family: "Teodor";
    font-style: normal;
    font-weight: 300;
    font-size: 56px;
    line-height: 56px;
    letter-spacing: -0.03em;
    color: #dbfbf6;
  }

  & .property-text {
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 20px;
    line-height: 26px;
    color: rgba(255, 255, 255, 0.8);
    padding-right: 73px;
    padding-top: 16px;
  }
`;

const StyledRight = styled.div`
  display: grid;
  grid-template-rows: 1fr 1fr;

  & > div {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 18px;
  }

  & > div:first-child {
    border-bottom: 1px solid #23524c;
  }

  & > div img {
    width: 144px;
    height: 144px;
    transition: all 0.2s ease-in-out;
  }

  & > div:hover img {
    transform: scale(1.2);
  }

  & .property-title {
    font-family: "Teodor";
    font-style: normal;
    font-weight: 300;
    font-size: 32px;
    line-height: 32px;
    letter-spacing: -0.02em;
    color: #dbfbf6;
    margin-top: 27px;
  }

  & .property-text {
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 16px;
    line-height: 21px;
    color: rgba(255, 255, 255, 0.8);
    padding-top: 12px;
  }
`;

const PropertyBlockRegular = () => {
  return (
    <>
      <StyledContainer className="first">
        <StyledLeft>
          <img src="/svg/powerful.svg" alt="" />
          <div>
            <div className="property-title">Powerful.</div>
            <div className="property-text">
              Advanced order types such as TWAP, Scale, and TP/SL. Modify and cancel directly
              from TradingView chart.
            </div>
          </div>
        </StyledLeft>
        <StyledRight>
          <div>
            <img src="/svg/zero.svg" alt="" />
            <div>
              <div className="property-title">Low fees.</div>
              <div className="property-text">
                Zero gas, maker rebates, and low taker fees.
              </div>
            </div>
          </div>
          <div>
            <img src="/svg/leverage.svg" alt="" />
            <div>
              <div className="property-title">Up to 50x leverage.</div>
              <div className="property-text">
                Trade with conviction to maximize capital efficiency when it
                matters most.
              </div>
            </div>
          </div>
        </StyledRight>
      </StyledContainer>
      <StyledContainer>
        <StyledLeft>
          <img src="/svg/fast.svg" alt="" />
          <div>
            <div className="property-title">Fast.</div>
            <div className="property-text">
              Instant finality in &lt;1 second.
              <br />
              No more waiting for confirmations. No more MEV.
            </div>
          </div>
        </StyledLeft>
        <StyledRight>
          <div>
            <img src="/svg/transparent.svg" alt="" />
            <div>
              <div className="property-title">Transparent.</div>
              <div className="property-text">
                Fully on-chain order book. Trades, funding, and liquidations all
                happen on the Hyperliquid L1.
              </div>
            </div>
          </div>
          <div>
            <img src="/svg/seamless.svg" alt="" />
            <div>
              <div className="property-title">Seamless.</div>
              <div className="property-text">
                One-click trading. No wallet approvals to interrupt your flow.
              </div>
            </div>
          </div>
        </StyledRight>
      </StyledContainer>
    </>
  );
};

export default PropertyBlockRegular;
