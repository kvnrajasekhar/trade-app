import React, { useState, useEffect } from "react";
import { styled } from "styled-components";
import { Media } from "../../Media";

const StyledStats = styled.div`
  margin: 20px auto 100px;
  border-radius: 12px;
  border: 1px solid #dedede;
  background: #f6fefd;
  box-shadow: 0px 14px 25px 0px #daede9;
  width: 826px;
  height: 129px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 13px;

  @media screen and (max-width: 1024px) {
    width: calc(100% - 10px);
    margin: -30px -10px 80px;
    height: 103px;
  }
`;

const StyledStatBlock = styled.div`
  border-right: 1px solid #dedede;
  height: 73px;
  width: 33.33%;
  text-align: center;

  &:last-child {
    border-right: none;
  }

  & h3 {
    padding-top: 8px;
    color: #072723;
    font-family: Inter;
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    line-height: 130%;
    opacity: 0.5;
  }

  & span {
    display: block;
    color: #02231e;
    text-align: center;
    font-family: Inter;
    font-size: 28px;
    font-style: normal;
    font-weight: 300;
    line-height: 100%;
    letter-spacing: -0.56px;
    margin-top: 8px;

    @media screen and (max-width: 1024px) {
      font-size: 16px;
    }
  }
`;

const Stats = ({ currencies }) => {
  const [stats, setStats] = useState();

  useEffect(() => {
    const loadStats = async () => {
      const request = await fetch(
        `${process.env.GATSBY_ROOT_URL.split("app.").join("api.")}/info`,
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ type: "globalStats" }),
        }
      );
      const content = await request.json();
      setStats(content);
    };

    loadStats();
  }, []);

  return (
    <StyledStats>
      <StyledStatBlock>
        <Media lessThan="lg">
          <h3>24H Vol.</h3>
        </Media>
        <Media greaterThan="md">
          <h3>24H Volume</h3>
        </Media>
        <Media lessThan="lg">
          <span>
            {stats
              ? `$${Math.floor(stats.dailyVolume).toLocaleString(undefined, {
                  notation: "compact",
                })}`
              : "-"}
          </span>
        </Media>
        <Media greaterThan="md">
          <span>
            {stats ? `$${Math.floor(stats.dailyVolume).toLocaleString()}` : "-"}
          </span>
        </Media>
      </StyledStatBlock>
      <StyledStatBlock>
        <h3>Users</h3>
        <span>{stats ? stats.nUsers.toLocaleString() : "-"}</span>
      </StyledStatBlock>
      <StyledStatBlock>
        <h3>Assets</h3>
        <span>{currencies.length > 0 ? currencies.length : "-"}</span>
      </StyledStatBlock>
    </StyledStats>
  );
};

export default Stats;
