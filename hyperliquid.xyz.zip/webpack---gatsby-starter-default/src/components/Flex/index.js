import classNames from "classnames";
import React from "react";
import { StyledFlex } from "./Flex.styled";

export default function Flex({
  className,
  style,
  children,
  asHTMLTag = "div",
  display = "flex",
  flexDirection = "row",
  flexWrap,
  gap,
  rowGap,
  columnGap,
  fullWidth = false,
  justifyContent,
  alignContent,
  alignItems,
  ...interactionEvents
}) {
  return (
    <StyledFlex
      {...interactionEvents}
      className={classNames(className)}
      style={{
        ...style,
        ...(display ? { display } : {}),
        ...(fullWidth ? { width: "100%" } : {}),
        ...(flexDirection ? { flexDirection } : {}),
        ...(flexWrap ? { flexWrap } : {}),
        ...(gap ? { gap } : {}),
        ...(rowGap ? { rowGap } : {}),
        ...(columnGap ? { columnGap } : {}),
        ...(fullWidth ? { width: "100%" } : {}),
        ...(justifyContent ? { justifyContent } : {}),
        ...(alignContent ? { alignContent } : {}),
        ...(alignItems ? { alignItems } : {}),
      }}
      as={asHTMLTag}
    >
      {children}
    </StyledFlex>
  );
}
