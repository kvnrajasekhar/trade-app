import styled from "styled-components";

export const StyledFlex = styled.div``;
