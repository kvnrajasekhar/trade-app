import { styled } from "styled-components";

const StyledMobileBreak = styled.br`
  display: none;

  @media screen and (max-width: 1024px) {
    display: initial;
  }
`;

const StyledItalic = styled.span`
  font-style: italic;
`;

export { StyledItalic, StyledMobileBreak };
