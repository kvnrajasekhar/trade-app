import React from "react";
import { styled } from "styled-components";

const StyledCtaBlock = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  background: url(/svg/big-circles.svg);
  background-repeat: no-repeat;
  background-position: center center;
  background-size: 100% auto;
  height: 785px;

  @media screen and (max-width: 1024px) {
    height: auto;
    aspect-ratio: 1.23/1;
    background-size: cover;
  }
`;

const StyledBigCta = styled.a`
  position: relative;
  width: 60%;
  aspect-ratio: 11.2/4;
  border-radius: 100em;
  background: #97fce4;
  font-family: "Inter";
  font-style: normal;
  font-weight: 300;
  font-size: 64px;
  letter-spacing: -0.03em;
  text-transform: uppercase;
  text-align: center;
  text-decoration: none;
  color: #193833;
  display: flex;
  justify-content: center;
  align-items: center;

  & img {
    height: 120px;
    width: 120px;
    vertical-align: middle;
  }

  &:hover {
    background: #50d2c1;
    color: #193833;
  }
  &:active {
    background: #33998c;
    color: #193833;
  }

  @media screen and (max-width: 1024px) {
    width: 90%;
    height: 120px;
    line-height: 120px;
    font-size: 28px;
  }
`;

const CtaBlock = () => {
  return (
    <StyledCtaBlock>
      <StyledBigCta href={`${process.env.GATSBY_ROOT_URL}/trade`}>
        Start Trading
      </StyledBigCta>
    </StyledCtaBlock>
  );
};

export default CtaBlock;
