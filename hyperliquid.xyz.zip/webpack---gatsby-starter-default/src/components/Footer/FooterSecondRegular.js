import React from "react";
import { styled } from "styled-components";

const StyledFooter = styled.div`
  font-family: "Inter";
  font-style: normal;
  font-weight: 400;
  font-size: 12px;
  line-height: 16px;
  color: #ffffff;
  padding-top: 170px;
  padding-bottom: 20px;
  display: grid;
  grid-template-columns: 100px 1fr 100px;
  justify-content: center;
  text-align: center;
  align-items: center;

  & img {
    height: 62px;
    width: 62px;
    margin: 0 auto;
  }

  & .tou-link {
    color: white;
    text-decoration: none;
  }

  & .tou-link:hover {
    text-decoration: underline;
  }
`;

const FooterSecondRegular = () => {
  return (
    <StyledFooter>
      <div style={{ textAlign: "left" }}>2023</div>
      <img
        src="/gif/blob-light.gif"
        alt=""
        style={{ width: "62px", height: "62px" }}
      />
      <div style={{ textAlign: "right" }}>
        <a href="https://hyperliquid.xyz/terms" className="tou-link">
          Terms of use
        </a>
      </div>
    </StyledFooter>
  );
};

export default FooterSecondRegular;
