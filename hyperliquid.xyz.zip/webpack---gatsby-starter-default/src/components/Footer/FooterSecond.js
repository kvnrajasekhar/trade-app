import React from "react";
import { Media } from "../../Media";
import FooterSecondMobile from "./FooterSecondMobile";
import FooterSecondRegular from "./FooterSecondRegular";

const FooterSecond = () => {
  return (
    <>
      <Media lessThan="lg">
        <FooterSecondMobile />
      </Media>
      <Media greaterThan="md">
        <FooterSecondRegular />
      </Media>
    </>
  );
};

export default FooterSecond;
