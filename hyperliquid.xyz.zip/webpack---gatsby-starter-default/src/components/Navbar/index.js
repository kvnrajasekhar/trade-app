import React from "react";
import { Media } from "../../Media";
import RegularNavbar from "./RegularNavbar";
import CenteredContent from "../CenteredContent";
import MobileNavbar from "./MobileNavbar";

export default function Navbar() {
  return (
    <CenteredContent>
      <Media lessThan="lg">
        <MobileNavbar />
      </Media>
      <Media greaterThan="md">
        <RegularNavbar />
      </Media>
    </CenteredContent>
  );
}
