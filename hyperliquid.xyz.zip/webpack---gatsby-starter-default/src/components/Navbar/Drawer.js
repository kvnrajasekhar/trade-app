import React from "react";
import { styled, keyframes } from "styled-components";
import Grid from "../Grid";
import Flex from "../Flex";
import { Link } from "gatsby";

const fadeInFromNone = keyframes`
  0% {
    display: none;
    opacity: 0;
  }

  1% {
    display: grid;
    opacity: 0;
  }

  100% {
    display: grid;
    opacity: 1;
  }
`;

const StyledDrawer = styled.div`
  display: grid;
  animation: ${fadeInFromNone} 0.5s ease-out;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background: #072723;
  padding: 26px;
  grid-template-rows: auto 1fr auto auto;
  gap: 40px;
  z-index: 2000;
`;

const StyledDrawerLink = styled(Link)`
  display: block;
  line-height: 56px;
  padding: 0 8px;
  font-family: "Teodor";
  font-style: normal;
  font-weight: 200;
  font-size: 24px;
  letter-spacing: -0.03em;
  color: #dbfbf6;
  border-top: 1px solid #23524c;
  text-decoration: none;

  &.first {
    border-top: none !important;
  }
`;

const StyledMajorCTA = styled.a`
  display: block;
  background: #97fce4;
  border-radius: 60px;
  height: 96px;
  line-height: 96px;
  text-align: center;
  font-family: "Inter";
  font-style: normal;
  font-weight: 400;
  font-size: 20px;
  text-transform: uppercase;
  text-decoration: none;
  color: #193833;

  & a.major-cta:hover {
    background: #50d2c1;
    color: #193833;
  }

  & a.major-cta:active {
    background: #33998c;
    color: #193833;
  }
`;

const StyledFooter = styled.div`
  border-top: 1px solid #23524c;
  padding-top: 24px;
  display: flex;
  gap: 24px;

  & a:active svg *,
  & a:hover svg * {
    fill: #97fce4;
  }

  & a {
    color: white;
    text-decoration: none;
  }
  & a:hover {
    text-decoration: underline;
  }

  & .sep {
    flex-grow: 1;
  }

  & .t-o-u {
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 20px;
    text-transform: uppercase;
    color: #ffffff;
  }
`;

export default function Drawer({ onClose }) {
  return (
    <StyledDrawer>
      <Grid
        gridTemplateColumns="auto 1fr"
        alignItems="center"
        justifyItems="center"
      >
        <img src="/svg/arrow_back.svg" alt="" onClick={onClose} />
        <Flex gap="12px" alignItems="center">
          <img src="/svg/blob-green.svg" alt="" />
          <img src="/svg/logo-mobile-white.svg" alt="Hyperliquid" />
        </Flex>
      </Grid>
      <Grid gridTemplateRows="1fr auto">
        <div>
          <StyledDrawerLink to="/vaults" className="first">
            Vaults
          </StyledDrawerLink>
          <StyledDrawerLink to="/guides">Guides</StyledDrawerLink>
          <StyledDrawerLink to="/blog">Blog</StyledDrawerLink>
          <StyledDrawerLink
            to="https://jobs.ashbyhq.com/Hyperliquid%20Labs"
            target="_blank"
          >
            Careers
          </StyledDrawerLink>
          <StyledDrawerLink
            target="_blank"
            rel="noreferrer"
            to="https://stats.hyperliquid.xyz/"
          >
            Stats
          </StyledDrawerLink>
        </div>
        <StyledMajorCTA href={`${process.env.GATSBY_ROOT_URL}/trade`}>
          Launch app
        </StyledMajorCTA>
      </Grid>
      <StyledFooter>
        <a href="https://discord.gg/hyperliquid">
          <svg
            width="32"
            height="32"
            viewBox="0 0 32 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M12 4.66663C9.56599 4.66663 7.72432 5.07739 5.70623 6.0682C5.59095 6.1248 5.49445 6.21349 5.42837 6.32363C4.04279 8.63295 1.33337 15.0612 1.33337 22.6666C1.33337 22.8398 1.40075 23.0061 1.52124 23.1305C2.78897 24.439 3.94288 25.4016 5.17968 26.0809C6.42376 26.7642 7.72064 27.1441 9.25377 27.3285C9.51475 27.36 9.7698 27.235 9.90504 27.0096L10.5865 25.8738C9.59447 25.5272 8.58261 25.0661 7.9596 24.443C7.56908 24.0525 7.56908 23.4194 7.9596 23.0289C8.35012 22.6384 8.98329 22.6384 9.37381 23.0289C9.71352 23.3686 10.5117 23.7554 11.6389 24.1172L11.6403 24.1176C12.5716 24.3617 14.1947 24.6666 16 24.6666C17.8054 24.6666 19.4282 24.3613 20.3595 24.1172C20.36 24.117 20.3607 24.1173 20.3611 24.1172C21.4883 23.7554 22.2866 23.3686 22.6263 23.0289C23.0168 22.6384 23.6499 22.6384 24.0404 23.0289C24.431 23.4194 24.431 24.0525 24.0404 24.443C23.4175 25.0661 22.4056 25.5272 21.4135 25.8738L22.0951 27.0096C22.2303 27.235 22.4854 27.36 22.7463 27.3285C24.2795 27.1441 25.5763 26.7642 26.8204 26.0809C28.0572 25.4016 29.2111 24.439 30.4788 23.1305C30.5994 23.0061 30.6667 22.8398 30.6667 22.6666C30.6667 15.0612 27.9572 8.63295 26.5716 6.32363C26.5056 6.21349 26.4091 6.1248 26.2939 6.0682C24.2758 5.07739 22.434 4.66663 20 4.66663C19.7131 4.66663 19.4583 4.85025 19.3676 5.12248L18.9194 6.46713C18.8095 6.43164 18.6882 6.39472 18.5563 6.35788C17.9182 6.17961 17.023 5.99996 16 5.99996C14.9771 5.99996 14.0819 6.17961 13.4438 6.35788C13.3119 6.39472 13.1905 6.43164 13.0807 6.46713L12.6325 5.12248C12.5417 4.85025 12.287 4.66663 12 4.66663ZM13.3334 17C13.3334 18.2886 12.4379 19.3333 11.3334 19.3333C10.2288 19.3333 9.33337 18.2886 9.33337 17C9.33337 15.7113 10.2288 14.6666 11.3334 14.6666C12.4379 14.6666 13.3334 15.7113 13.3334 17ZM20.6667 19.3333C21.7712 19.3333 22.6667 18.2886 22.6667 17C22.6667 15.7113 21.7712 14.6666 20.6667 14.6666C19.5622 14.6666 18.6667 15.7113 18.6667 17C18.6667 18.2886 19.5622 19.3333 20.6667 19.3333Z"
              fill="#F6FEFD"
            />
          </svg>
        </a>
        <a href="https://medium.com/@hyperliquid">
          <svg
            width="32"
            height="32"
            viewBox="0 0 32 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M17.3334 14.6666C17.3334 19.0849 13.7516 22.6666 9.33337 22.6666C4.91509 22.6666 1.33337 19.0849 1.33337 14.6666C1.33337 10.2483 4.91509 6.66663 9.33337 6.66663C13.7516 6.66663 17.3334 10.2483 17.3334 14.6666ZM26.3334 14.6666C26.3334 18.7168 24.6918 22 22.6667 22C20.6416 22 19 18.7168 19 14.6666C19 10.6165 20.6416 7.33329 22.6667 7.33329C24.6918 7.33329 26.3334 10.6165 26.3334 14.6666ZM29.3334 21.3333C30.0698 21.3333 30.6667 18.3485 30.6667 14.6666C30.6667 10.9847 30.0698 7.99996 29.3334 7.99996C28.597 7.99996 28 10.9847 28 14.6666C28 18.3485 28.597 21.3333 29.3334 21.3333Z"
              fill="#F6FEFD"
            />
          </svg>
        </a>
        <a href="https://t.me/hyperliquid_announcements">
          <svg
            width="32"
            height="32"
            viewBox="0 0 32 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M16 30.6667C24.1002 30.6667 30.6667 24.1002 30.6667 16C30.6667 7.89987 24.1002 1.33337 16 1.33337C7.89987 1.33337 1.33337 7.89987 1.33337 16C1.33337 24.1002 7.89987 30.6667 16 30.6667ZM6.19212 15.2544C6.06519 15.3022 5.97612 15.4308 5.97612 15.5666C5.97612 15.7022 6.06519 15.8308 6.19212 15.8784L10.1748 17.3331L18.3802 13.0958C18.4664 13.0529 18.5795 13.0823 18.634 13.1618C18.6886 13.2414 18.6752 13.3574 18.6042 13.4224L13.0817 18.3758L19.2695 23.3584C19.3583 23.423 19.4783 23.4392 19.5812 23.401C19.684 23.3627 19.7642 23.272 19.7895 23.1651L23.0668 9.38117C23.0951 9.26323 23.0539 9.13319 22.9628 9.05308C22.8718 8.97299 22.7375 8.94871 22.6242 8.99184L6.19212 15.2544Z"
              fill="#F6FEFD"
            />
          </svg>
        </a>
        <a href="https://twitter.com/HyperliquidX">
          <svg
            width="32"
            height="32"
            viewBox="0 0 32 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M1.33337 25.3342C22.1562 33.4162 28.0508 18.633 27.8731 11.3341C29.5644 10.8727 30.6667 9.72149 30.6667 8.54049C29.2699 9.27447 28.5398 9.06587 27.8414 8.54049C29.3454 7.51617 29.2699 6.05588 29.2699 5.04844C28.5667 5.41705 27.2651 6.32831 25.7778 6.44528C24.7834 4.89035 22.2858 3.65164 18.7936 5.04845C15.3016 6.44527 14.6032 10.1701 15.3016 12.0326C10.8318 12.0326 5.52385 7.37649 3.42861 5.04845C0.917558 8.63148 4.09435 12.1855 5.52385 13.4294C4.57087 13.7144 3.42861 13.4294 2.7302 12.731C2.7302 16.719 6.22227 18.3182 7.61909 19.0168H4.82544C4.82544 21.8104 8.08469 22.9744 9.71432 23.2072C8.59687 24.3246 4.09476 25.3342 1.33337 25.3342Z"
              fill="#F6FEFD"
            />
          </svg>
        </a>
        <div className="sep"></div>
        <div className="t-o-u">
          2023
          <br />
          <a href="https://hyperliquid.xyz/terms">Terms of use</a>
        </div>
      </StyledFooter>
    </StyledDrawer>
  );
}
