import React from "react";
import { styled } from "styled-components";
import Flex from "../Flex";
import { Link } from "gatsby";

const StyledRegularNavbar = styled.div`
  height: 56px;
  margin-top: 16px;
  background: #ffffff;
  box-shadow: 0px 2px 12px rgba(7, 39, 35, 0.06);
  border-radius: 100px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 8px 8px 8px 16px;
  box-sizing: border-box;
  position: fixed;
  width: 1200px;
  max-width: calc(100% - 60px);
  z-index: 1000;
`;

const StyledCTA = styled.a`
  padding: 9px 24px;
  height: 40px;
  background: #97fce4;
  border-radius: 60px;
  font-size: 16px;
  font-weight: 400;
  line-height: 22px;
  color: #193833;
  text-decoration: none;
  box-sizing: border-box;

  &:hover {
    background: #50d2c1;
    color: #193833;
  }
  &:active {
    background: #33998c;
    color: #193833;
  }
`;

const StyledNavbarLinked = styled(Link)`
  font-family: "Inter";
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  color: #072723;
  text-decoration: none;
  transition: color 0.15s ease-in-out;

  &:hover {
    color: #349a8d;
  }
`;

const StyledNavbarOutsideLinked = styled.a`
  font-family: "Inter";
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  color: #072723;
  text-decoration: none;
  transition: color 0.15s ease-in-out;

  &:hover {
    color: #349a8d;
  }
`;

const StyledNavbarDropdown = styled.div`
  position: relative;
  font-family: "Inter";
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  color: #072723;
  text-decoration: none;
  transition: color 0.15s ease-in-out;
  cursor: pointer;

  &:hover {
    color: #349a8d;
  }

  & > .content {
    display: none;
  }

  &:hover > .content {
    display: block;
  }
`;

const StyledNavbarDropdownContentPadder = styled.div`
  position: absolute;
  top: 0px;
  left: 0px;
  width: 100px;
  height: 100px;
`;

const StyledNavbarDropdownContent = styled.div`
  position: absolute;
  top: 50px;
  left: -10px;
  padding: 18px;
  background: #ffffff;
  box-shadow: 0px 2px 12px 0px rgba(7, 39, 35, 0.06);
  border-radius: 20px;
  width: 120px;
`;

export default function RegularNavbar() {
  return (
    <StyledRegularNavbar>
      <a href="/">
        <img src="/svg/logo.svg" alt="Hyperliquid" />
      </a>
      <Flex alignItems="center" gap={23}>
        <StyledNavbarLinked to="/vaults">Vaults</StyledNavbarLinked>
        <StyledNavbarLinked to="/blog">Blog</StyledNavbarLinked>
        <StyledNavbarLinked
          to="https://jobs.ashbyhq.com/Hyperliquid%20Labs"
          target="_blank"
        >
          Careers
        </StyledNavbarLinked>
        <StyledNavbarDropdown>
          Resources
          <StyledNavbarDropdownContentPadder className="content">
            <StyledNavbarDropdownContent>
              <Flex flexDirection="column" gap={6}>
                <StyledNavbarOutsideLinked
                  href="https://hyperliquid.gitbook.io/hyperliquid-docs/"
                  target="_blank"
                  rel="noreferrer"
                >
                  Docs
                </StyledNavbarOutsideLinked>
                <StyledNavbarLinked to="/guides">Guides</StyledNavbarLinked>
                <StyledNavbarLinked to="/markets">Markets</StyledNavbarLinked>
                <StyledNavbarOutsideLinked
                  href="https://stats.hyperliquid.xyz/"
                  target="_blank"
                  rel="noreferrer"
                >
                  Stats
                </StyledNavbarOutsideLinked>
              </Flex>
            </StyledNavbarDropdownContent>
          </StyledNavbarDropdownContentPadder>
        </StyledNavbarDropdown>
        <div>
          <StyledCTA href={`${process.env.GATSBY_ROOT_URL}/trade`}>
            Launch App
          </StyledCTA>
        </div>
      </Flex>
    </StyledRegularNavbar>
  );
}
