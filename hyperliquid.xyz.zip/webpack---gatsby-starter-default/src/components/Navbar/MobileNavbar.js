import React, { useState } from "react";
import { styled } from "styled-components";
import Drawer from "./Drawer";

const StyledMobileNavbar = styled.div`
  text-align: center;
  height: 48px;
  margin-top: 12px;
  background: #ffffff;
  box-shadow: 0px 2px 12px rgba(7, 39, 35, 0.06);
  border-radius: 100px;
  display: grid;
  align-items: center;
  justify-items: center;
  box-sizing: border-box;
  padding: 0 4px 0 12px;
  margin-left: -15px;
  grid-template-columns: 24px 22px 1fr 80px;
  position: fixed;
  width: 1200px;
  max-width: calc(100% - 30px);
  z-index: 1000;

  & > img.logo {
    height: 24px;
  }
`;

const StyledCTA = styled.a`
  padding: 9px 12px;
  height: 40px;
  background: #97fce4;
  border-radius: 60px;
  font-size: 16px;
  font-weight: 400;
  line-height: 22px;
  color: #193833;
  text-decoration: none;
  box-sizing: border-box;

  &:hover {
    background: #50d2c1;
    color: #193833;
  }
  &:active {
    background: #33998c;
    color: #193833;
  }
`;

export default function MobileNavbar() {
  const [opened, setOpened] = useState(false);
  return (
    <>
      <StyledMobileNavbar>
        <img
          src="/svg/hamburger.svg"
          alt="Menu"
          onClick={() => setOpened(true)}
        />
        <div></div>
        <img src="/svg/logo-mobile.svg" className="logo" alt="Hyperliquid" />
        <StyledCTA href={`${process.env.GATSBY_ROOT_URL}/trade`}>
          Launch
        </StyledCTA>
      </StyledMobileNavbar>
      {opened && <Drawer onClose={() => setOpened(false)} />}
    </>
  );
}
