import React from "react";
import { styled } from "styled-components";

const StyledBigTitle = styled.div`
  padding-top: 186px;
  margin-bottom: -6px;
  display: flex;
  align-items: start;

  & .logo {
    height: 134px;
    width: 134px;
    margin-top: -60px;
  }

  @media screen and (max-width: 1024px) {
    padding-top: 100px;
    margin-bottom: -2px;

    & .very-big-title {
      max-width: calc(100% - 60px);
    }

    & .logo {
      height: 40px;
      width: 40px;
      margin-top: -20px;
    }
  }
`;

const VeryBigTitle = () => {
  return (
    <StyledBigTitle>
      <img
        src="/svg/big-logo.svg"
        className="very-big-title"
        alt="Hyperliquid"
      />
      <img src="/gif/blob-dark.gif" className="logo" alt="" />
    </StyledBigTitle>
  );
};

export default VeryBigTitle;
