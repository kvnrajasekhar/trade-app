import React from "react";
import { styled } from "styled-components";

const StyledRoadmap = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;

  & .road {
    display: flex;
    flex-direction: column;
    flex-grow: 1;
    align-items: center;
  }

  & .road .bar {
    margin: 0 auto;
    width: 1px;
    background: #0f3933;
    opacity: 0.5;
    height: 100%;
    flex-grow: 0;
  }

  & .road .spacing {
    height: 24px;
  }

  & .road .title {
    margin: 0 auto;
    font-family: "Inter";
    font-style: normal;
    font-weight: 300;
    font-size: 28px;
    line-height: 28px;
    letter-spacing: 12px;
    color: #072723;
    padding: 90px 0;
    padding-left: 12px;
    text-transform: uppercase;
  }

  & .road .subtitle {
    display: block;
    font-family: "Inter";
    font-style: normal;
    font-weight: 700;
    font-size: 14px;
    line-height: 18px;
    text-align: center;
    color: #193833;
    padding: 24px 0;
    text-transform: uppercase;
    margin: 0 auto;
  }

  & .road .subtitle .liner {
    display: none;
  }

  & .road .text {
    font-family: "Inter";
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 18px;
    text-align: center;
    color: #193833;
  }

  & .road .chip {
    margin: 28px auto;
    font-family: "Inter";
    font-style: normal;
    font-weight: 700;
    font-size: 12px;
    line-height: 16px;
    text-align: center;
    color: #193833;
  }

  & .road .chip span {
    display: inline-block;
    background: #97fce4;
    border-radius: 24px;
    padding: 2px 12px;
  }

  & .road .chip .liner {
    display: none;
  }

  & .road .soon {
    margin: 24px auto 0;
    font-family: "Inter";
    font-style: normal;
    font-weight: 700;
    font-size: 14px;
    line-height: 18px;
    text-align: center;
    color: #193833;
  }

  & .road .soon .liner {
    display: none;
  }

  & .road .launch {
    margin: 8px auto 40px;
    font-family: "Teodor";
    font-style: normal;
    font-weight: 300;
    font-size: 56px;
    line-height: 56px;
    letter-spacing: -0.03em;
    color: #193833;
    text-align: center;
  }

  @media screen and (max-width: 1024px) {
    display: grid;
    grid-template-columns: 1fr;
    gap: 3px;

    & .road .bar {
      display: none;
    }

    & .road .soon,
    & .road .chip,
    & .road .subtitle {
      display: grid;
      grid-template-columns: 1fr auto 1fr;
      gap: 24px;
      align-items: center;
      width: 100%;
    }

    & .road .soon .liner,
    & .road .chip .liner,
    & .road .subtitle .liner {
      height: 1px;
      background: #193833;
      width: 100%;
      display: block;
      opacity: 0.5;
    }

    & .road .spacing {
      height: 8px;
    }

    & .road .launch {
      font-size: 64px;
      line-height: 64px;
    }
  }
`;

const Roadmap = () => {
  return (
    <StyledRoadmap>
      <div className="road">
        <div className="title">Roadmap</div>
        <div className="bar" style={{ height: "210px" }}></div>
        <div className="subtitle half-opacity">
          <div className="liner"></div>
          Q4 2022
          <div className="liner"></div>
        </div>
        <div className="text half-opacity">
          Hyperliquid launches with offchain order matching on Arbitrum Goerli.
        </div>
        <div className="spacing"></div>
        <div className="text half-opacity">
          Hyperliquid transitions to the Hyperliquid L1, supporting 20,000
          orders per second with a fully onchain order book. Order matching is
          now onchain.
        </div>
        <div className="spacing"></div>
        <div className="bar" style={{ height: "76px" }}></div>
      </div>
      <div className="road">
        <div className="bar" style={{ height: "418px" }}></div>
        <div className="subtitle half-opacity">
          <div className="liner"></div>
          Q1 2023
          <div className="liner"></div>
        </div>
        <div className="text half-opacity">
          Vaults open on testnet, including liquidation and market making
          vaults.
        </div>
        <div className="spacing"></div>
        <div className="text half-opacity">
          Mainnet closed alpha goes live, including a referral rewards program
          and support for API trading.
        </div>
        <div className="spacing"></div>
        <div className="bar" style={{ height: "76px" }}></div>
      </div>
      <div className="road">
        <div className="bar" style={{ height: "80px" }}></div>
        <div className="chip">
          <div className="liner"></div>
          <span>NOW</span>
          <div className="liner"></div>
        </div>
        <div className="text">Mainnet closed alpha is live.</div>
        <div className="spacing"></div>
        <div className="bar" style={{ height: "500px" }}></div>
      </div>
      <div className="road">
        <div className="bar" style={{ height: "420px" }}></div>
        <div className="soon">
          <div className="liner"></div>
          Soon
          <div className="liner"></div>
        </div>
        <div className="launch">Beta launch</div>
        <div className="bar" style={{ height: "124px" }}></div>
      </div>
    </StyledRoadmap>
  );
};

export default Roadmap;
