import React from "react";

export default function Separator({ size }) {
  return <div style={{ height: `${size}px` }} />;
}
