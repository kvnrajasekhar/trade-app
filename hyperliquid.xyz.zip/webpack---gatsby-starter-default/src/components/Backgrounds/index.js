import { styled } from "styled-components";

const StyledGreenBlock = styled.div`
  background: #072723;
`;

const StyledDarkGreenBlock = styled.div`
  background: #02231e;
`;

const StyledDarkBlock = styled.div`
  background: #00100e;
`;

const StyledLightGreenBlock = styled.div`
  background: #dbfbf6;
`;

const StyledVectoredBlackGreen = styled.div`
  background: #02221b url(/svg/lines.svg) no-repeat;
  background-size: cover;
`;

export {
  StyledGreenBlock,
  StyledDarkGreenBlock,
  StyledLightGreenBlock,
  StyledVectoredBlackGreen,
  StyledDarkBlock,
};
